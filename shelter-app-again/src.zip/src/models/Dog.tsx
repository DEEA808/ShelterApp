export interface Dog{
    id:number,
    name:string,
    breed:string,
    description:string,
    age:number,
    story:string,
    gender:string,
    size:string,
    color:string,
    image:string
}