import React, { useState } from 'react';
import {
    Box,
    Typography,
    FormControl,
    RadioGroup,
    FormControlLabel,
    Radio,
    Button
} from '@mui/material';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const TRAITS = [
    {
        label: "intelligence",
        weightKey: "intelligenceWeight",
        subtraits: [
            { label: "Trainability Level", key: "trainabilityLevel" },
            { label: "Mental Simulation Needs", key: "mentalSimulationNeeds" }
        ]
    },
    {
        label: "hygiene",
        weightKey: "hygieneWeight",
        subtraits: [
            { label: "Shedding Level", key: "sheddingLevel" },
            { label: "Drooling Level", key: "droolingLevel" }
        ]
    },
    {
        label: "friendliness",
        weightKey: "friendlinessWeight",
        subtraits: [
            { label: "Affectionate with Family", key: "affectionateWithFamily" },
            { label: "Openness to Strangers", key: "opennessToStrangers" },
            { label: "Playfulness Level", key: "playfulnessLevel" }
        ]
    },
    {
        label: "adaptability",
        weightKey: "adaptabilityWeight",
        subtraits: [
            { label: "Good with Other Dogs", key: "goodWithOtherDogs" },
            { label: "Good with Children", key: "goodWithChildren" }
        ]
    },
    {
        label: "energy",
        weightKey: "energyWeight",
        subtraits: [
            { label: "Energy Level", key: "energyLevel" },
            { label: "Barking Level", key: "barkingLevel" }
        ]
    },
    {
        label: "popularity",
        weightKey: "popularityWeight",
        subtraits: [
            { label: "Popularity", key: "popularity" }
        ]
    },
    {
        label: "longevity",
        weightKey: "lengevityWeight",
        subtraits: [
            { label: "Longevity", key: "longevity" }
        ]
    },
    {
        label: "food cost",
        weightKey: "foodCostWeight",
        subtraits: [
            { label: "Food Cost", key: "foodCost" }
        ]
    }
];

type WeightLabel = "Not important" | "Important" | "Really important" | "I don't care";
type ScoreLabel = "Low" | "Medium" | "High";
type FormValue = WeightLabel | ScoreLabel;

const weightOptions: Record<WeightLabel, number> = {
    "Not important": 1,
    "Important": 2,
    "Really important": 3,
    "I don't care": 0
};

const scoreOptions: Record<ScoreLabel, number> = {
    "Low": 1,
    "Medium": 2,
    "High": 3
};

const reversedScoreOptions: Record<ScoreLabel, number> = {
    "Low": 3,
    "Medium": 2,
    "High": 1
};

function isWeightLabel(value: any): value is WeightLabel {
    return Object.keys(weightOptions).includes(value);
}

function isScoreLabel(value: any): value is ScoreLabel {
    return Object.keys(scoreOptions).includes(value);
}



const UserPreferencesFormPage: React.FC = () => {
    const [formData, setFormData] = useState<Record<string, FormValue>>({});
    const navigate = useNavigate();
    const [matchResult, setMatchResult] = useState(null);
    const [error, setError] = useState<string | null>(null);

    const reversedKeys = new Set(["sheddingLevel", "droolingLevel", "longevity", "barkingLevel"]);


    const handleChange = (key: string, value: FormValue) => {
        setFormData((prev) => ({ ...prev, [key]: value }));
    };


    const handleSubmit = async () => {
        const backendData: Record<string, number | string> = {};

        if (formData.size) {
            backendData["size"] = formData.size as string;
        }

        for (const key in formData) {
            const value = formData[key];

            if (isWeightLabel(value)) {
                backendData[key] = weightOptions[value];
            } else if (isScoreLabel(value)) {
                backendData[key] = reversedKeys.has(key)
                    ? reversedScoreOptions[value]
                    : scoreOptions[value];
            }
        }


        const token = localStorage.getItem("token");

        if (!token) {
            setError("Authentication error: Please log in.");
            return;
        }
        console.log("🚀 Backend data:", backendData);
        console.log("🔐 Token:", token);

        try {
            const response = await axios.post('http://localhost:8005/dogs/perfectMatch', backendData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });

            navigate('/topBreeds', { state: { topBreeds: response.data } });

        } catch (error: any) {
            console.error('❌ Error fetching perfect match:', error);
            if (error.response) {
                console.error("Response data:", error.response.data);
                console.error("Status:", error.response.status);
                console.error("Headers:", error.response.headers);
            }
            setError("Something went wrong. Check the console for details.");
        }

    };





    return (
        <Box
            sx={{
                backgroundColor: "#F5EDE3",
                minHeight: '100vh',
                width: '100%',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'flex-start',
                py: 4,
                px: 2,
            }}
        >
            <Box
                sx={{
                    marginLeft: "300px",
                    display: 'flex',
                    flexDirection: 'column',
                    width: '100%',
                    maxWidth: 800,
                }}
            >
                <Typography sx={{ fontWeight: 'bold' }} variant="h4" gutterBottom>Choose the desire traits for your future dog</Typography>

                <FormControl component="fieldset" sx={{ mb: 4 }}>
                    <Typography sx={{ fontWeight: 'bold', color: '#D86B5C' }} variant="h6">
                        Dog size
                    </Typography>
                    <RadioGroup
                        value={formData.size || ''}
                        onChange={(e) => handleChange('size', e.target.value as FormValue)}
                    >
                        <FormControlLabel value="small" control={<Radio />} label="Small" />
                        <FormControlLabel value="medium" control={<Radio />} label="Medium" />
                        <FormControlLabel value="large" control={<Radio />} label="Large" />
                        <FormControlLabel value="any" control={<Radio />} label="Doesn't matter" />
                    </RadioGroup>
                </FormControl>
                {TRAITS.map(({ label, weightKey, subtraits }) => (
                    <Box key={label} sx={{ mb: 4, color: "#E08E84" }}>
                        <Typography sx={{ fontWeight: 'bold', color: '#D86B5C' }} variant="h6">{label}</Typography>

                        <FormControl component="fieldset" sx={{ mt: 1 }}>
                            <Typography sx={{ fontWeight: 'bold' }} variant="subtitle2">How important is {label}?</Typography>
                            <RadioGroup
                                value={formData[weightKey] || ''}
                                onChange={(e) => handleChange(weightKey, e.target.value as FormValue)}
                            >
                                {Object.keys(weightOptions).map((opt) => (
                                    <FormControlLabel key={opt} value={opt} control={<Radio />} label={opt} />
                                ))}
                            </RadioGroup>
                        </FormControl>

                        {subtraits.map(({ label: subLabel, key }) => (
                            <FormControl component="fieldset" sx={{ mt: 1, marginLeft: "40px" }}>
                                <Typography sx={{ fontWeight: 'bold' }} variant="subtitle2">{subLabel}</Typography>
                                <RadioGroup
                                    value={formData[key] || ''}
                                    onChange={(e) => handleChange(key, e.target.value as FormValue)}
                                >
                                    {Object.keys(scoreOptions).map((opt) => (
                                        <FormControlLabel key={opt} value={opt} control={<Radio />} label={opt} />
                                    ))}
                                </RadioGroup>
                            </FormControl>
                        ))}
                    </Box>
                ))}

                <Button sx={{ backgroundColor: "#E08E84", color: "black",width:"150px",marginLeft:"700px"}} variant="contained" onClick={handleSubmit}>Submit</Button>

                {matchResult && (
                    <Box sx={{ mt: 4 }}>
                        <Typography variant="h5">Perfect Match Results</Typography>
                        <pre>{JSON.stringify(matchResult, null, 2)}</pre>
                    </Box>
                )}
            </Box>
        </Box>
    );

};

export default UserPreferencesFormPage;
