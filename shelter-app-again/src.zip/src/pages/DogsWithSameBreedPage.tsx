import React, { useEffect, useState } from "react";
import axios from "axios";
import { addDataUrlPrefix } from "../utils/ImageUtils"; // Ensure correct path
import { Dog } from "../models/Dog";
import "../GetAllPage.css";
import { useNavigate, useParams } from "react-router-dom";
import { useShelter } from "../utils/ShelterContext";
import CsvUploader from "../utils/CSVUploader";
import { getRolesFromToken } from "../utils/Auth";
import { Trash2 } from "lucide-react";
import { fetchShelterDetails } from "../utils/ShelterUtils";
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button } from "@mui/material";
import pawIcon from "../assets/paw.png"

const DogsWithSameBreedPage: React.FC = () => {
  const [dogs, setDogs] = useState<Dog[]>([]); // ✅ Ensure `dogs` is an array
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const { selectedShelterId } = useShelter();
  const navigate = useNavigate();
  const userRoles = getRolesFromToken();
  const token = localStorage.getItem("token");
  const [userShelterId, setUserShelterId] = useState<number | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedDogIdToDelete, setSelectedDogIdToDelete] = useState<number | null>(null);
  const { breedName } = useParams<{ breedName: string }>();


  const fetchDogs = () => {
    if (!selectedShelterId) {
      navigate("/shelters");
      return;
    }
    axios
      .get(`http://localhost:8005/dogs/byBreed/${breedName}`, {
        headers: {
          Authorization: `Bearer ${token}`, 
        },
      })
      .then(async (response) => {
        console.log("API Response:", response.data); 
        setDogs(Array.isArray(response.data) ? response.data : []); 
        setLoading(false);
        const shelterData = await fetchShelterDetails(token);
        if (shelterData) {
          setUserShelterId(shelterData.id);
        }
        console.log(userShelterId);
      })
      .catch(async (error) => {
        console.error("Error fetching dogs:", error);
        if (error.response && error.response.status === 403) {
          setError("Access denied: You do not have permission.");
          navigate("/"); 
        } else {
          setError("Failed to load dogs.");
        }
        setDogs([]); 
        setLoading(false);
      });
  }

  useEffect(() => {
    fetchDogs();
  }, [selectedShelterId, navigate]);


  const handleForwardClick = () => {
    navigate("/appointments");
  }

  const filterDogs = Array.isArray(dogs)
    ? dogs.filter((dog) =>
      dog.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    : [];

  const handleDogClick = (dogId: number) => {
    navigate(`/dogProfile/${dogId}`);
  };

  if (loading) return <p>Loading dogs...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="shelter-page">
      <div className="sidebar">
        <button className="back-button" onClick={() => navigate(-1)}>
          ←
        </button>
      </div>

      <div>
        {/* Search Bar */}
        <div className="search-container">
          <input
            type="text"
            className="search-bar"
            placeholder="Search dogs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/*  Grid */}
      <div className="shelter-grid">
        {filterDogs.length > 0 ? (
          filterDogs.map((dog) => {
            const imageType: "png" | "jpeg" = dog.image.includes("/9j/")
              ? "jpeg"
              : "png";
            const imageSrc = dog.image
              ? addDataUrlPrefix(dog.image, imageType)
              : null;

            return (
              <div key={dog.id} className="shelter-card" >
                {imageSrc && (
                  <img key={dog.id} src={imageSrc} alt={dog.name} className="shelter-image" onClick={() => handleDogClick(dog.id)} />
                )}
                <h3>{dog.name}</h3>
                <p>{dog.breed}</p>
              </div>
            );
          })
        ) : (
          <p>No dogs found</p>
        )}
      </div>
      <div className="header-container">
        <h1>
          <span className="word">My</span>
          <span className="word">Appointments</span>
        </h1>
        <button className="forward-button" onClick={handleForwardClick}>→</button>
      </div>
    </div>
  );
};

export default DogsWithSameBreedPage;
